Upload 'index.html' and 'preview.jpg' to your GitHub Pages repository.
Formspree is already set up for email contact.
URL: https://marcusthelma.github.io/